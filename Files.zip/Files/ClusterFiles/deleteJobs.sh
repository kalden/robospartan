#!/bin/bash

for ((i= 1795933; i <= 1796181; i = i + 1))
do
	qdel $i
done
