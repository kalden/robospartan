File description

ConsistencyAnalysis.sh - Organizes files for the Consistency Analysis technique 
progressBar.sh - Just illustrates progress.
