FileDescription

- setVariables.sh - File used to assign parameter values.
- runSimulations.sh - Runs the simulations for N parameters values and for N repetitions. This files duplicates the .argos file, creates directories and allocate files.
- processdata.sh - File used to modify files in order to highlight the value of interest.
